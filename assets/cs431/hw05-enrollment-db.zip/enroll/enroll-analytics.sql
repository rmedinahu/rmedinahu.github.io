-- enroll-analytics.sql

-- place your sql statements for creating course, semester, and schedule tables below.