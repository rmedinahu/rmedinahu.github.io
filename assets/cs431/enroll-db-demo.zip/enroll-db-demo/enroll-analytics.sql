-- enroll-analytics.sql homework 5 DDL statements

-- place your sql statements for creating course, semester, and schedule tables below.


-- csv column order: PK,SUB,NUM,TITLE
create table courses (
	pk int not null,
	dept varchar(6),
	level int,
	title varchar(512),
	primary key(pk)
);

-- csv column order: PK,TERM_CODE,TERM_TITLE
create table semesters (
	pk int not null,
	code int,
	title varchar(48),
	primary key(pk)
);


-- csv column order: PK,CRS_ID,SEM_ID,CRN,TYPE,SECT,MAX,ACT
create table schedules (
	pk int not null,
	course_pk int not null,
	semester_pk int not null,
	crn int not null,
	type varchar(48) not null,
	section int not null,
	max_enroll int not null,
	actual_enroll int not null,
	primary key(pk),
	foreign key(course_pk) references courses(pk),
	foreign key(semester_pk) references semesters(pk)
);


